-- fxmanifest.lua
fx_version 'bodacious'
game 'gta5'

author 'Your Name'
description 'FiveM Airstrikes'
version '1.0.0'

server_script 'server.lua'
client_script 'client.lua'
