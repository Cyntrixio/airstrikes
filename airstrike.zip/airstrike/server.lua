-- server.lua
-- Handles server-side commands and communication

RegisterCommand('airstrikes', function(source, args, rawCommand)
    local player = source
    TriggerClientEvent('triggerAirstrikes', player)
end, false)

-- No permissions required for this command (the "false" argument).
