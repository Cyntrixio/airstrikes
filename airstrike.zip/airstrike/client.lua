-- client.lua
-- Handles client-side airstrikes

local isAirstrikesActive = false

-- Function to simulate an airstrike
function Airstrike()
    local playerPed = GetPlayerPed(-1)
    local pos = GetEntityCoords(playerPed)
    
    -- Updated radius ranges for larger airstrike coverage
    local startX, startY, startZ = pos.x + math.random(-40, 40), pos.y + math.random(-40, 40), pos.z + 100
    local targetX, targetY = pos.x + math.random(-30, 30), pos.y + math.random(-30, 30)
    local targetZ = pos.z

    -- Create explosions in expanded random locations
    AddExplosion(targetX, targetY, targetZ, 15, 5.0, true, false, 1.0)

end

-- Trigger the airstrike when the server event is fired
RegisterNetEvent('triggerAirstrikes')
AddEventHandler('triggerAirstrikes', function()
    if not isAirstrikesActive then
        isAirstrikesActive = true
        local numberOfStrikes = 50
        local delayBetweenStrikes = 666 -- Time in milliseconds
        
        -- Notify the player that airstrikes are starting
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {"Luftangriff", "Luftangriffssequenz eingeleitet."}
        })
        
        -- Loop to perform multiple airstrikes
        for i = 1, numberOfStrikes do
            Citizen.Wait(delayBetweenStrikes)
            Airstrike()
        end
        
        -- Notify the player that airstrikes have ended
        TriggerEvent('chat:addMessage', {
            color = {0, 255, 0},
            multiline = true,
            args = {"Luftangriff", "Luftangriffssequenz abgeschlossen."}
        })
        
        isAirstrikesActive = false
    else
        -- Notify the player that airstrikes are already in progress
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {"Luftangriff", "Die Luftangriffe sind bereits im Gange."}
        })
    end
end)
